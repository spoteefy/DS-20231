# HUST_DATASCIENCE_CLASS_PROJECT
## Folder
- [name]: private folder for each member. Ex: bach
- expriments: unofficial code used for experimenting
- utils.py: helper code
- normalized_data: processed data used for analyzing
- data: raw data
- tasks: code that perform a specific task(only for finalized code)

## Data statistics
- vnw: all jobs
- itviec: only it jobs
- topcv: only it jobs
- vieclam24h: all jobs
- timviec365: all jobs

## MAIN QUESTIONS:
- Which skills are needed for a particular IT job position


## Step to collect IT jobs:

- Extract it jobs position from category column
- Extract it jobs from dataset having mixed jobs(vnw, vieclam24h, timviec365) then aggregate with other only-it dataset(topcv, itvice)

